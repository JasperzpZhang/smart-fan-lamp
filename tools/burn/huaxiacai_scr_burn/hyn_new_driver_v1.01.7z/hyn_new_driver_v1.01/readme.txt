
sys节点操作
1、升级
    echo fd /sdcard/xxx.bin >/sys/hynitron_debug/hyntpdbg
    或用default名称 “app.bin”
    echo fd>/sys/hynitron_debug/hyntpdbg
2、write 
    eg:写 d1 01 02 03 04
    echo w d1 01 02 03 04 >/sys/hynitron_debug/hyntpdbg
3、read
    eg 读 20 byte
    echo r 20 >/sys/hynitron_debug/hyntpdbg && cat /sys/hynitron_debug/hyntpdbg
3、read reg （max reg长度4 byte max read 256 byte）
    eg:写 d1 01 读 2 byte
    echo w d1 01 r 2 >/sys/hynitron_debug/hyntpdbg && cat /sys/hynitron_debug/hyntpdbg
    eg:写 d1 01 02 03 读 20 byte
    echo w d1 01 02 03 r 20 >/sys/hynitron_debug/hyntpdbg && cat /sys/hynitron_debug/hyntpdbg
    如果reg 不变可以直接用 cat /sys/hynitron_debug/hyntpdbg 读（reg沿用上次的操作）
    
4、读版TP_FW本号
    cat /sys/hynitron_debug/hyntpfwver


参考dts配置:
    hynitron@5A {
        compatible = "hyn_ts";
        reg = <0x5A>;
        vdd_ana-supply = <&pm8953_l10>;
        vcc_i2c-supply = <&pm8953_l6>;

        interrupt-parent = <&tlmm>;
        interrupts = <65 0x02>;
        reset-gpio = <&tlmm 64 0x01>;
        irq-gpio = <&tlmm 65 0x02>;
        
        pinctrl-names = "ts_active","ts_suspend";
        pinctrl-0 = <&ts_int_active &ts_reset_active>;
        pinctrl-1 = <&ts_int_suspend &ts_reset_suspend>;
        
        max-touch-number = <5>;
        display-coords = <0 0 800 1280>;
        pos-swap = <0>;
        posx-reverse = <0>;
        posy-reverse = <0>;

        key-number = <0>;
        keys = <139 102 158>;
        key-y-coord = <2000>;
        key-x-coords = <200 600 800>;
    };


